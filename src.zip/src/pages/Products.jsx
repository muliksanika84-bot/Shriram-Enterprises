function Products() {
  return (
    <div>
      <h1>Our Products</h1>
      <h3>Turmeric Powder 100g</h3>
      <p>₹50</p>
    </div>
  );
}

export default Products;