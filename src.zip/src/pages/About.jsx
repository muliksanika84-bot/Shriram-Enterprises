function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>
        Shriram Enterprises provides premium quality turmeric powder
        and other natural spices.
      </p>
    </div>
  );
}

export default About;