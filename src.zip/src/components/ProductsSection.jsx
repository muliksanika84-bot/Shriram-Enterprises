import "./ProductsSection.css";
import turmeric50 from "../assets/images/turmeric50g.jpeg";
import turmeric100 from "../assets/images/turmeric100g.jpeg";
import { FaArrowRight } from "react-icons/fa";

function ProductsSection() {
  return (
    <section className="products-section" data-aos="fade-up">

      <div className="section-title">
        <h2>Our Premium Products</h2>
        <p>
          Naturally farm-sourced turmeric powder, hygienically packed to
          preserve freshness, purity and authentic taste.
        </p>
      </div>

      <div className="products-container">

        <div className="product-card">

          <div className="product-image">
            <img src={turmeric50} alt="Turmeric Powder 50g" />
          </div>

          <h3>Turmeric Powder 50g</h3>

          <p>
            Perfect for everyday cooking. Pure, natural turmeric powder with
            rich colour, aroma and freshness.
          </p>

          <button>
            View Details <FaArrowRight />
          </button>

        </div>

        <div className="product-card featured">

          <span className="best-seller">
            Best Seller
          </span>

          <div className="product-image">
            <img src={turmeric100} alt="Turmeric Powder 100g" />
          </div>

          <h3>Turmeric Powder 100g</h3>

          <p>
            Ideal for families looking for premium quality turmeric with no
            added colours or harmful chemicals.
          </p>

          <button>
            View Details <FaArrowRight />
          </button>

        </div>

      </div>

    </section>
  );
}

export default ProductsSection;