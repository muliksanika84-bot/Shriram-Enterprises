import "./Hero.css";
import { FaLeaf, FaArrowRight } from "react-icons/fa";
import turmeric100 from "../assets/images/turmeric100g.jpeg";

function Hero() {
  return (
    <section className="hero" data-aos="fade-up">
  id="home"
  data-aos="fade-up"


      <div className="hero-content">

        <span className="hero-badge">
          <FaLeaf />
          100% Pure & Natural
        </span>

        <h1>
          Premium <span>Turmeric Powder</span>
        </h1>

        <p>
          Experience the richness of naturally farm-sourced turmeric.
          Hygienically processed and packed with care.
        </p>

        <div className="hero-buttons">
          <button className="primary-btn">
            Explore Products
            <FaArrowRight />
          </button>

          <button className="secondary-btn">
            Contact Us
          </button>
        </div>

        <div className="hero-features">
          <span>🌾 Farm Fresh</span>
          <span>🛡️ No Chemicals</span>
          <span>📦 Hygienically Packed</span>
          <span>⭐ Premium Quality</span>
        </div>

      </div>

      <div className="hero-image">
        <img
          src={turmeric100}
          alt="Turmeric Powder"
        />
      </div>

    </section>
  );
}

export default Hero;