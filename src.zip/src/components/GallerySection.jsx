import "./GallerySection.css";

import turmeric50 from "../assets/images/turmeric50g.jpeg";
import turmeric100 from "../assets/images/turmeric100g.jpeg";

function GallerySection() {
  return (

    <section
  className="gallery"
  id="gallery"
  data-aos="zoom-in"
>

      <div className="section-title">
        <h2>Product Gallery</h2>
      </div>

      <div className="gallery-grid">

        <img src={turmeric50} alt="50g" />

        <img src={turmeric100} alt="100g" />

        <img src={turmeric50} alt="50g" />

        <img src={turmeric100} alt="100g" />

      </div>

    </section>
  );
}

export default GallerySection;