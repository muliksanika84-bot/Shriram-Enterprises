import "./ContactSection.css";
import {
  FaPhoneAlt,
  FaEnvelope,
  FaMapMarkerAlt,
} from "react-icons/fa";

function ContactSection() {
  return (
    <section className="contact-section" data-aos="fade-up">

      <div className="contact-info">

        <h2>Contact Us</h2>

        <p>
          We'd love to hear from you. Contact us for product enquiries,
          wholesale orders, or any questions about our turmeric powder.
        </p>

        <div className="info-box">
          <FaPhoneAlt />
          <span>+91 XXXXXXXXXX</span>
        </div>

        <div className="info-box">
          <FaEnvelope />
          <span>shriramenterprises@gmail.com</span>
        </div>

        <div className="info-box">
          <FaMapMarkerAlt />
          <span>Maharashtra, India</span>
        </div>

      </div>

      <form className="contact-form">

        <input
          type="text"
          placeholder="Your Name"
        />

        <input
          type="email"
          placeholder="Your Email"
        />

        <input
          type="tel"
          placeholder="Mobile Number"
        />

        <textarea
          rows="5"
          placeholder="Your Message"
        ></textarea>

        <button type="submit">
          Send Message
        </button>

      </form>
      <div className="map-container">
  <iframe
    title="Shriram Enterprises Location"
    src="https://www.google.com/maps?q=Maharashtra&output=embed"
    width="100%"
    height="350"
    style={{ border: 0 }}
    allowFullScreen=""
    loading="lazy"
  ></iframe>
</div>

    </section>
  );
}

export default ContactSection;