import "./Stats.css";

function Stats() {
  return (
    <section className="stats">

      <div className="stat-box">
        <h2>100%</h2>
        <p>Natural</p>
      </div>

      <div className="stat-box">
        <h2>2</h2>
        <p>Products</p>
      </div>

      <div className="stat-box">
        <h2>100%</h2>
        <p>Quality</p>
      </div>

      <div className="stat-box">
        <h2>24×7</h2>
        <p>Support</p>
      </div>

    </section>
  );
}

export default Stats;