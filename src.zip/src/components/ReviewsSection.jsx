import "./ReviewsSection.css";

function ReviewsSection() {
  return (
    <section
  className="reviews"
  data-aos="fade-left"
>

      <h2>Customer Reviews</h2>

      <div className="reviews-container">

        <div className="review-card">
          <h3>⭐⭐⭐⭐⭐</h3>
          <p>
            Very good quality turmeric powder. Excellent colour and aroma.
          </p>
          <span>- Happy Customer</span>
        </div>

        <div className="review-card">
          <h3>⭐⭐⭐⭐⭐</h3>
          <p>
            Fresh, hygienically packed and perfect for daily cooking.
          </p>
          <span>- Regular Buyer</span>
        </div>

        <div className="review-card">
          <h3>⭐⭐⭐⭐⭐</h3>
          <p>
            Premium quality product. Highly recommended.
          </p>
          <span>- Customer</span>
        </div>

      </div>

    </section>
  );
}

export default ReviewsSection;