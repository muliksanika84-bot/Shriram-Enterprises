import "./AboutSection.css";
import turmeric100 from "../assets/images/turmeric100g.jpeg";
import { FaLeaf, FaAward, FaSeedling } from "react-icons/fa";

function AboutSection() {
  return (
    <section className="about-section" data-aos="fade-right">
      <div className="about-image">
        <img
          src={turmeric100}
          alt="Shriram Enterprises Turmeric Powder"
        />
      </div>

      <div className="about-content">
        <span className="about-tag">About Shriram Enterprises</span>

        <h2>Delivering Pure & Premium Turmeric Powder</h2>

        <p>
          Shriram Enterprises is dedicated to delivering naturally
          farm-sourced turmeric powder with exceptional quality.
          Our products are hygienically processed and packed to
          preserve freshness, natural aroma, and authentic taste.
        </p>

        <div className="about-features">
          <div className="feature">
            <FaLeaf />
            <span>100% Pure & Natural</span>
          </div>

          <div className="feature">
            <FaSeedling />
            <span>Naturally Farm-Sourced</span>
          </div>

          <div className="feature">
            <FaAward />
            <span>Premium Quality</span>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AboutSection;