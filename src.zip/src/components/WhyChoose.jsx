import "./WhyChoose.css";
import { GiWheat } from "react-icons/gi";
import { FaLeaf, FaBoxOpen, FaAward } from "react-icons/fa";

function WhyChoose() {
  return (
    <section className="why-choose" data-aos="fade-up">
      <h2>Why Choose Shriram Enterprises?</h2>

      <p className="section-subtitle">
        We are committed to delivering premium-quality turmeric powder that is
        naturally farm-sourced, hygienically packed, and trusted by families
        for its purity, freshness, and authentic taste.
      </p>

      <div className="features">

        <div className="feature-card">
          <div className="icon">
            <GiWheat />
          </div>

          <h3>Farm Sourced</h3>

          <p>
            Carefully sourced from farms to preserve freshness and natural quality.
          </p>
        </div>

        <div className="feature-card">
          <div className="icon">
            <FaLeaf />
          </div>

          <h3>100% Pure</h3>

          <p>
            No added colours or harmful chemicals. Just pure turmeric goodness.
          </p>
        </div>

        <div className="feature-card">
          <div className="icon">
            <FaBoxOpen />
          </div>

          <h3>Hygienically Packed</h3>

          <p>
            Packed with care to maintain freshness, safety, and long shelf life.
          </p>
        </div>

        <div className="feature-card">
          <div className="icon">
            <FaAward />
          </div>

          <h3>Premium Quality</h3>

          <p>
            Rich colour, natural aroma, and authentic taste in every pack.
          </p>
        </div>

      </div>
    </section>
  );
}

export default WhyChoose;