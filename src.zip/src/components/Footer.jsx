import "./Footer.css";
import logo from "../assets/logo/logo.jpeg";
import {
  FaWhatsapp,
  FaInstagram,
  FaFacebook,
  FaPhoneAlt,
  FaEnvelope,
  FaMapMarkerAlt,
} from "react-icons/fa";

function Footer() {
  return (
    <footer className="footer" data-aos="fade-up">

      <div className="footer-container">

        <div className="footer-box">
          <img src={logo} alt="Shriram Enterprises Logo" className="footer-logo" />

          <h2>Shriram Enterprises</h2>

          <p>
            Delivering naturally farm-sourced turmeric powder with purity,
            freshness and premium quality.
          </p>
        </div>

        <div className="footer-box">

          <h3>Quick Links</h3>

          <ul>
            <li>Home</li>
            <li>About</li>
            <li>Products</li>
            <li>Contact</li>
          </ul>

        </div>

        <div className="footer-box">

          <h3>Contact</h3>

          <p>
            <FaPhoneAlt /> +91 9890070845
          </p>

          <p>
            <FaEnvelope /> shriramenterprises1512@gmail.com
          </p>

          <p>
            <FaMapMarkerAlt /> karad, Maharashtra, India
          </p>

        </div>

        <div className="footer-box">

          <h3>Follow Us</h3>

          <div className="social-icons">

           <a
  href="https://wa.me/919890070845?text=Hello%20Shriram%20Enterprises,%20I%20would%20like%20to%20know%20more%20about%20your%20products."
  target="_blank"
  rel="noopener noreferrer"
>
  <FaWhatsapp />
</a> 

            <a
  href="https://www.instagram.com/shriram.ent_official?igsh=M3dsaHk3YW5kYzRk"
  target="_blank"
  rel="noopener noreferrer"
>
  <FaInstagram />
</a>

            
            

          </div>

        </div>

      </div>

      <hr />

      <p className="copyright">
        © 2026 Shriram Enterprises. All Rights Reserved.
      </p>

    </footer>
  );
}

export default Footer;